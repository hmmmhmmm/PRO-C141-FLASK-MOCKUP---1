# Flask-Mockup-1
PRO-C141

In this project we are going to start creating our Flask API for Screen 1 of our Mobile App for article recommendation.
